package com.examen;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        
        Controlador cc = new Controlador(); //Me creo el controlador
        
        //Creo valoracionRevista
        valoracionRevistas val1 = new valoracionRevistas("revista1", 10);

        //Creo equipos
        equipos equipo1 = new equipos("equipo1", "Cuenca", "1", "primera");
        equipos equipo2 = new equipos("equipo2", "Cuenca", "2", "primera");
        equipos equipo3 = new equipos("equipo3", "Cuenca", "3", "primera");
        equipos equipo4 = new equipos("equipo4", "Cuenca", "4", "primera");

        //Creo partidos
        partidos partido1 = new partidos(equipo3, equipo4, 12, 34, "2023-2024");
        partidos partido2 = new partidos(equipo1, equipo2, 162, 384, "2023-2024");
        partidos partido3 = new partidos(equipo2, equipo3, 124, 334, "2023-2024");
        partidos partido4 = new partidos(equipo1, equipo4, 122, 134, "2023-2024");

        

        //Creo jugadores
        jugadores jug1 = new jugadores("jugador1", "procedencia1", "198", 102, "alero", equipo1);
        jugadores jug2 = new jugadores("jugador2", "procedencia2", "200", 110, "pivote", equipo2);
        jugadores jug3 = new jugadores("jugador3", "procedencia3", "201", 100, "base", equipo3);
        jugadores jug4 = new jugadores("jugador4", "procedencia4", "215", 105, "alero", equipo4);
        jugadores jug5 = new jugadores("jugador5", "procedencia5", "210", 108, "alero", equipo4);
        List<jugadores> jugList1 = new ArrayList<jugadores>();
        jugList1.add(jug1);
        jugList1.add(jug2);
        List<jugadores> jugList2 = new ArrayList<jugadores>();
        jugList2.add(jug3);
        List<jugadores> jugList3 = new ArrayList<jugadores>();
        jugList3.add(jug4);
        List<jugadores> jugList4 = new ArrayList<jugadores>();
        jugList4.add(jug5);

        partido1.setJugadores(jugList1);
        partido1.setJugadores(jugList2);
        partido1.setJugadores(jugList3);
        partido1.setJugadores(jugList4);
        cc.meterPartido(partido1);
        cc.meterPartido(partido2);
        cc.meterPartido(partido3);
        cc.meterPartido(partido4);

        equipo1.setJugadores(jugList1);
        equipo2.setJugadores(jugList2);
        equipo3.setJugadores(jugList3);
        equipo4.setJugadores(jugList4);

        cc.meterEquipo(equipo1);
        cc.meterEquipo(equipo2);
        cc.meterEquipo(equipo3);
        cc.meterEquipo(equipo4);
        
        //establecimiento del jugador a la valoracion
        val1.setJugador(jug5);
        cc.meterValoracionRevista(val1);
        
        cc.meterJugador(jug1);
        cc.meterJugador(jug2);
        cc.meterJugador(jug3);
        cc.meterJugador(jug4);
        cc.meterJugador(jug5);
    
    }//main


}//Main